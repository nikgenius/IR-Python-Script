#Created By Nikhil Chowdhary
#Oct-27-2017
#Incident Response Script-WINDOWS
#***********************************************

import os
import platform
import datetime

#Checking The Current OS
def chkos():
    if platform.system() == 'Windows':# checking od OS is Windows
        print("The Operating System Of This Computer Is: = ", platform.system(), "\n")
    else:
        print("This Is Not A Windows Computer. This Script Is Only Made For A Windows Computer.", "\n")
        print("Hence, Exiting The Script. Have A Good Day")
        exit()

# Checking If The Output Directory
def chkdir():
    try:
        print("Checking If The Output Directory Exists", "\n")
        if os.path.isdir('C:\FinalProject'):  # checking id directory exists
            print("The Output Directory Already Exists", "\n")
        else:
            print("The Output Directory DOES NOT Exist. Creating The Directory Now", "\n")
            os.makedirs('C:/FinalProject')  # creating the directory if it does NOT exist
    except: # This Is An Exception Just In Case OS Is Not Able To Determine and Create Directory
        print("Sorry Cannot Determine If The Output Directory Already Exists. Please Create C:\FinalProject Manually")

# Script****Scripts's Start Date and Time****
def startdatetime():
    print("Capturing And Saving The System's Current Date and Time At The Beginning Of The Script", "\n")
    open('C:/FinalProject/StartDateTime.txt', "w").write(datetime.datetime.now().ctime()) #creating a file with script starting date and time

#**** System Version, Services and Processes****
def vsp():
    print("Capturing And Saving The System's Name and Version", "\n")
    open('C:/FinalProject/SysNameVer.txt', 'w').write(platform.version() + '\n')#saving the OS version
    open('C:/FinalProject/SysNameVer.txt', 'a').write(platform.node())#appending the system name in the same file

    print("****Please Ensure That DUMPSEC Application Is Saved In The Same Working Directory****")
    print("Capturing And Saving The System's Services Names, Status and Type", "\n")
    os.system("dumpsec /rpt=services /saveas=csv /outfile=C:/FinalProject/%COMPUTERNAME%.local-services.csv")
# running an external DUMPSEC application to gather and save System's Services Names, Status and Type

    print("Capturing And Saving The System's Running Task Names, PID, Session#, Used Memory, Status, User Name, CPU Time and Window Title", "\n")
    os.system("Tasklist /v > C:/FinalProject/%COMPUTERNAME%.Tasklist.txt")
    #Capturing And Saving The System's Running Task Names, PID, Session#, Used Memory, Status, User Name, CPU Time and Window Title

    print("Capturing And Saving The Services That Are Currently Running On The System", "\n")
    os.system("Net Start > C:/FinalProject/%COMPUTERNAME%.networkservices.txt")
    #Capturing And Saving The Services That Are Currently Running On The System

    print("Capturing And Saving The Network Statistics By Protocol", "\n")
    os.system("netstat -s > C:/FinalProject/%COMPUTERNAME%.nbtstat1.txt")
    #Capturing And Saving The Network Statistics By Protocol

    print("Capturing And Saving All Active TCP and UDP Network Statistics", "\n")
    os.system("netstat -na > C:/FinalProject/%COMPUTERNAME%.netstat.txt")
    #Capturing And Saving All Active TCP and UDP Network Statistics

    print("Capturing And Saving The Interface List and Route Table For IPv4 and IPv6", "\n")
    os.system("netstat -fport > C:/FinalProject/%COMPUTERNAME%.fports.txt")
    #Capturing And Saving The Interface List and Route Table For IPv4 and IPv6

#****Shares and Users****
def sharesnusers():
    print("****Please Ensure That DUMPSEC Application Is Saved In The Same Working Directory****")
    print("Capturing And Saving The System Share Permissions", "\n")
    os.system("dumpsec /rpt=shares /saveas=csv /outfile=C:/FinalProject/%COMPUTERNAME%.shares.csv")
#Capturing And Saving The System Share Permissions using external DUMPSEC Application

    print("****Please Ensure That DUMPSEC Application Is Saved In The Same Working Directory****")
    print("Capturing And Saving The System's User Accounts and Their Permissions", "\n")
    os.system("dumpsec /rpt=users /saveas=csv /outfile=C:/FinalProject/%COMPUTERNAME%.lsusers.csv /showaudit")
#Capturing And Saving The System's User Accounts and Their Permissions using external DUMPSEC Application


#****System Registry****
def sysreg():
    print("Capturing And Saving The System's Registry Of Running Applications", "\n")
    os.system("Reg export HKLM\Software\Microsoft\Windows\CurrentVersion\Run C:/FinalProject/%COMPUTERNAME%.Run.reg")
    #Capturing And Saving The System's Registry Of Running Applications

    print("Capturing And Saving The System's Registry Of Applications That Only Ran Once", "\n")
    os.system("Reg export HKLM\Software\Microsoft\Windows\CurrentVersion\RunOnce C:/FinalProject/%COMPUTERNAME%.RunOnce.reg")
    #Capturing And Saving The System's Registry Of Applications That Only Ran Once

    print("Capturing And Saving The System's Registry Of Applications Started By The User", "\n")
    os.system("Reg export HKCU\Software\Microsoft\Windows\CurrentVersion\Run C:/FinalProject/%COMPUTERNAME%.UserRun.reg")
    #Capturing And Saving The System's Registry Of Applications Started By The User

    print("Capturing And Saving The System's Registry Of Applications Started By The User Only Once", "\n")
    os.system("Reg export HKCU\Software\Microsoft\Windows\CurrentVersion\Run C:/FinalProject/%COMPUTERNAME%.UserRunOnce.reg")
    #Capturing And Saving The System's Registry Of Applications Started By The User Only Once

#****Scheduled Tasks****
def schtsk():
    print("Capturing And Saving The System's Scheduled Tasks", "\n")
    os.system("Schtasks > C:/FinalProject/%COMPUTERNAME%.schtasks.txt")
    #Capturing And Saving The System's Scheduled Tasks

#****Storage File System and Large Files****
def strsystem():
    print("Checking The System Storage Disk Stats and Saving To Log File", "\n")
    os.system("chkdsk /f d: > C:/FinalProject/%COMPUTERNAME%.ntfs.txt")
    #Checking The System Storage Disk Stats and Saving To Log File

#****Sysinternals Tools- Autoruns****
def systools():
    print("Checking And Saving The List Of Programs Which Are Configured To Run During System Bootup Or Login")
    print("****Please Ensure That AUTORUNSC64 Application Is Saved In The Same Working Directory****", "\n")
    os.system("autorunsc64 -ct > C:/FinalProject/%COMPUTERNAME%.autorunsc64.txt")
    #Checking And Saving The List Of Programs Which Are Configured To Run During System Bootup Or Login Using AUTORUNSC64 External Application

#Nirsoft Tool - NetworkTrafficView****
def nirsoft():
    print("Capturing Network Traffic for 30 Seconds. Thank you for your patience!")
    print("****Please Ensure That NETWORKTRAFFICVIEW Application Is Saved In The Same Working Directory****", "\n")
    os.system("NetworkTrafficView /sverhtml C:/FinalProject/%COMPUTERNAME%_NetworkTrafficView.html /CaptureTime 30")
    #Capturing Network Traffic for 30Seconds Using External NETWORKTRAFFICVIEW Application

#Script****Script's End Date and Time****
def enddatetime():
    print("Capturing And Saving The System's Current Date and Time Again At The End Of The Script", "\n")
    open('C:/FinalProject/EndDateTime.txt', "w").write(datetime.datetime.now().ctime())
    #Capturing And Saving The System's Current Date and Time Again At The End Of The Script

chkos()
chkdir()
startdatetime()
vsp()
sharesnusers()
sysreg()
schtsk()
strsystem()
systools()
nirsoft()
enddatetime()

print("The Python Incident Response Script Is Now Complete. Please Refer To Log Files Created For Further Analysis")
